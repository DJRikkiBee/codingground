#include <iostream>
#include <string>

using namespace std;

int power(int base, int exp);
int multiply(int op1, int op2);

int main()
{
    int Result = 1;

    // Base
    int X = 2;
    // Exponent
    int N = 10;

    while (N > 0)
    {
        Result = Result * X;
        N--;
    }

    cout << Result << endl;

    Result = 1;
    // Base
    X = 2;
    // Exponent
    N = 20;

    while (N > 0)
    {
        Result = Result * X;
        N--;
    }

    cout << Result << endl;

    // First call
    Result = power(2, 10);

    cout << Result << endl;

    // Second call
    Result = power(2, 20);

    cout << Result << endl;

    return 0;
}


int power(int base, int exp)
{
    int result = 1;

    while (exp > 0)
    {
        result = multiply(result, base);
        exp--;
    }

    return result;
}
// You probably wouldn't do this real life.
// Use the * operator instead.
int multiply(int op1, int op2)
{
    int result = 0;

    for (int x = 0; x < op2; x++)
    {
        result = result + op1;
    }

    return result;
}
